from django.contrib import admin

# Register your models here.
from .models import Season, Championship, Teams, Round, Full_Record

class Prossima(admin.ModelAdmin):
      list_display = ['id', 'season','championship','round', 'date', 'time', 'match']
admin.site.register(Full_Record, Prossima)



admin.site.register(Season)
admin.site.register(Championship)
admin.site.register(Teams)
admin.site.register(Round)