from django import forms
from persons.models import Full_Record

class Full_RecordCreationForm(forms.ModelForm):
    partita = forms.CharField(required=False, disabled=True)

    class Meta:
        model = Full_Record
        fields = ['championship']



    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['match'].queryset = Full_Record.objects.none()

        if 'championship' in self.data:
            try:
                campionato_id = int(self.data.get('championship'))
                self.fields['match'].queryset = Full_Record.objects.filter(campionato_id=campionato_id).order_by('name')
            except (ValueError, TypeError):
                pass  # invalid input from the client; ignore and fallback to empty City queryset
            
