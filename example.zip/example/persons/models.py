from django.db import models
from smart_selects.db_fields import ChainedForeignKey
from  django.contrib import admin

#################################### BASIC DATA ####################################

#Season
class Season(models.Model):
    name = models.CharField(max_length=40)
    
    def __str__(self):
        return self.name
    
#Championship
class Championship(models.Model):
    season = models.ForeignKey(Season, on_delete=models.CASCADE)
    name = models.CharField(max_length=40)

    def __str__(self):
        return self.name

#Round
class Round(models.Model):
    season = models.ForeignKey(Season, on_delete=models.CASCADE)
    championship = models.ForeignKey(Championship, on_delete=models.CASCADE)

    name = models.CharField(max_length=40)
    def __str__(self):
        return self.name

#Teams
class Teams(models.Model):
    season = models.ForeignKey(Season, on_delete=models.CASCADE)
    championship = models.ForeignKey(Championship, on_delete=models.CASCADE)


    name = models.CharField(max_length=40)
    def __str__(self):
        return self.name

#################################################################################################

#################################### FULL RECORD ####################################

class Full_Record(models.Model):
    season = models.ForeignKey(Season, on_delete=models.CASCADE)
    championship = models.ForeignKey(Championship, on_delete=models.CASCADE)
    

    round = ChainedForeignKey(
        Round,
        chained_field="championship",
        chained_model_field="championship",
        show_all=False,
        auto_choose=True,
        sort=True)

    team_home = ChainedForeignKey(
        Teams,
        related_name='team_home_name',
        chained_field="championship",
        chained_model_field="championship",
        show_all=False,
        auto_choose=True,
        sort=True)
    
    team_away = ChainedForeignKey(
        Teams,
        related_name='team_away_name',
        chained_field="championship",
        chained_model_field="championship",
        show_all=False,
        auto_choose=True,
        sort=True)


    date = models.DateField()

    time = models.TimeField()


    @property
    def match(self):
        return f"{self.team_home}-{self.team_away}"


   


   

